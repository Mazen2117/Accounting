import streamlit as st
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="Tree Accounting Pro", layout="wide")
st.title("Accounting System")

uploaded_file = st.file_uploader("Upload Your Cleaned Excel File", type=["xlsx"])

if uploaded_file:
    try:
        def get_clean_df(uploaded_file, sheet_name):
            df = pd.read_excel(uploaded_file, sheet_name=sheet_name)
            df = df.dropna(how='all').reset_index(drop=True)
            if df.columns.str.contains('Unnamed').any():
                for i in range(len(df)):
                    row_vals = [str(v).lower() for v in df.iloc[i].values]
                    if 'code' in row_vals or 'account' in row_vals:
                        df.columns = df.iloc[i].astype(str).str.strip()
                        df = df.iloc[i+1:].reset_index(drop=True)
                        break
            df.columns = [str(c).strip() for c in df.columns]
            return df

        if 'df_entries' not in st.session_state:
            st.session_state.df_entries = get_clean_df(uploaded_file, 'Enetry')
        
        if 'manual_beg_balances' not in st.session_state:
            st.session_state.manual_beg_balances = pd.DataFrame(columns=['Code', 'Beg_Dr', 'Beg_Cr'])

        df_codes = get_clean_df(uploaded_file, 'Accounts Codes (2)')
        df_trial_orig = get_clean_df(uploaded_file, 'Trial Balance')

        df_codes['code'] = df_codes['code'].astype(str).str.strip()
        df_trial_orig['Code'] = df_trial_orig['Code'].astype(str).str.strip()
        
        code_col_tree = 'code'
        name_col_tree = [c for c in df_codes.columns if 'name' in c.lower()][0]

        st.sidebar.header("Data Entry")
        
        with st.sidebar.expander("Set Initial Balances (Beg)"):
            leaf_only_beg = df_codes[df_codes[code_col_tree].str.len() == 9]
            all_options_beg = leaf_only_beg[code_col_tree].tolist()
            
            with st.form("beg_balance_form"):
                target_code = st.selectbox("Select Account (9 digits only)", all_options_beg)
                b_dr = st.number_input("Beginning Debit", min_value=0.0)
                b_cr = st.number_input("Beginning Credit", min_value=0.0)
                if st.form_submit_button("Update Balance"):
                    st.session_state.manual_beg_balances = st.session_state.manual_beg_balances[st.session_state.manual_beg_balances['Code'] != target_code]
                    new_beg = pd.DataFrame([{'Code': target_code, 'Beg_Dr': b_dr, 'Beg_Cr': b_cr}])
                    st.session_state.manual_beg_balances = pd.concat([st.session_state.manual_beg_balances, new_beg], ignore_index=True)
                    st.success(f"Updated {target_code}")
                    st.rerun()

        with st.sidebar.expander("Post Daily Entry"):
            leaf_accounts = df_codes[df_codes[code_col_tree].str.len() == 9]
            leaf_options = leaf_accounts[code_col_tree].tolist()
            with st.form("double_entry_form"):
                entry_date = st.date_input("Date", datetime.now())
                dr_code = st.selectbox("Debit Account (Dr)", leaf_options)
                cr_code = st.selectbox("Credit Account (Cr)", leaf_options)
                amount = st.number_input("Amount", min_value=0.01)
                explanation = st.text_input("Explanation")
                
                last_no = pd.to_numeric(st.session_state.df_entries['Journal No.'], errors='coerce').max()
                new_journal_no = 1 if pd.isna(last_no) else int(last_no) + 1
                
                if st.form_submit_button("Post Entry"):
                    if dr_code == cr_code: st.error("Debit & Credit must be different!")
                    else:
                        def get_info(code):
                            info = df_codes[df_codes[code_col_tree] == code].iloc[0]
                            return info[name_col_tree], {'1':'Asset','2':'Liability','3':'Equity','4':'Revenue','5':'Expense'}.get(code[0], 'Other')
                        dr_name, dr_type = get_info(dr_code)
                        cr_name, cr_type = get_info(cr_code)
                        new_rows = [
                            {'Date': str(entry_date), 'Code': dr_code, 'Account name': dr_name, 'Dr': amount, 'Cr': 0, 'Journal No.': new_journal_no, 'Explanation': explanation, 'Type of Account': dr_type},
                            {'Date': "", 'Code': cr_code, 'Account name': cr_name, 'Dr': 0, 'Cr': amount, 'Journal No.': new_journal_no, 'Explanation': explanation, 'Type of Account': cr_type}
                        ]
                        st.session_state.df_entries = pd.concat([st.session_state.df_entries, pd.DataFrame(new_rows)], ignore_index=True)
                        st.rerun()

        entries = st.session_state.df_entries.copy()
        entries['Dr'] = pd.to_numeric(entries['Dr'], errors='coerce').fillna(0)
        entries['Cr'] = pd.to_numeric(entries['Cr'], errors='coerce').fillna(0)
        entries['Code'] = entries['Code'].astype(str).str.strip()

        expanded_moves = []
        for _, row in entries.iterrows():
            c = row['Code']
            if len(c) == 9:
                for lv in [c[0], c[:3], c[:6], c]:
                    expanded_moves.append({'Code': lv, 'Dr': row['Dr'], 'Cr': row['Cr']})
        
        movements = pd.DataFrame(expanded_moves).groupby('Code').agg({'Dr': 'sum', 'Cr': 'sum'}).reset_index() if expanded_moves else pd.DataFrame(columns=['Code', 'Dr', 'Cr'])
        movements.columns = ['Code', 'Move_Dr', 'Move_Cr']

        manual_beg_raw = st.session_state.manual_beg_balances
        expanded_beg = []
        for _, row in manual_beg_raw.iterrows():
            c = str(row['Code'])
            if len(c) == 9:
                for lv in [c[0], c[:3], c[:6], c]:
                    expanded_beg.append({'Code': lv, 'Beg_Dr': row['Beg_Dr'], 'Beg_Cr': row['Beg_Cr']})
        
        manual_beg_sum = pd.DataFrame(expanded_beg).groupby('Code').agg({'Beg_Dr': 'sum', 'Beg_Cr': 'sum'}).reset_index() if expanded_beg else pd.DataFrame(columns=['Code', 'Beg_Dr', 'Beg_Cr'])

        trial_beg_ex = df_trial_orig.copy()
        trial_beg_ex['Beg_Dr_Ex'] = pd.to_numeric(trial_beg_ex.iloc[:, 2], errors='coerce').fillna(0)
        trial_beg_ex['Beg_Cr_Ex'] = pd.to_numeric(trial_beg_ex.iloc[:, 3], errors='coerce').fillna(0)
        
        trial_combined_beg = pd.merge(trial_beg_ex[['Code', 'Beg_Dr_Ex', 'Beg_Cr_Ex']], manual_beg_sum, on='Code', how='outer').fillna(0)
        trial_combined_beg['Beg_Dr_Agg'] = trial_combined_beg['Beg_Dr_Ex'] + trial_combined_beg['Beg_Dr']
        trial_combined_beg['Beg_Cr_Agg'] = trial_combined_beg['Beg_Cr_Ex'] + trial_combined_beg['Beg_Cr']

        base_tree = df_codes[[code_col_tree, name_col_tree]].copy()
        base_tree.columns = ['Code', 'Account Name']
        
        final_trial = pd.merge(base_tree, trial_combined_beg[['Code', 'Beg_Dr_Agg', 'Beg_Cr_Agg']], on='Code', how='left').fillna(0)
        final_trial = pd.merge(final_trial, movements, on='Code', how='left').fillna(0)
        
        final_trial['Total_Dr'] = final_trial['Beg_Dr_Agg'] + final_trial['Move_Dr']
        final_trial['Total_Cr'] = final_trial['Beg_Cr_Agg'] + final_trial['Move_Cr']
        final_trial['Final_Dr'] = (final_trial['Total_Dr'] - final_trial['Total_Cr']).clip(lower=0)
        final_trial['Final_Cr'] = (final_trial['Total_Cr'] - final_trial['Total_Dr']).clip(lower=0)

        t1, t2, t3 = st.tabs(["Trial Balance", "Journal Entries", "Dashboard"])

        with t1:
            st.subheader("Hierarchical Trial Balance")
            mask = (final_trial['Beg_Dr_Agg'] != 0) | (final_trial['Beg_Cr_Agg'] != 0) | \
                   (final_trial['Move_Dr'] != 0) | (final_trial['Move_Cr'] != 0)
            report = final_trial[mask].copy()
            
            report['Beg Dr Display'] = report.apply(lambda x: x['Beg_Dr_Agg'] if len(str(x['Code'])) == 9 else 0, axis=1)
            report['Beg Cr Display'] = report.apply(lambda x: x['Beg_Cr_Agg'] if len(str(x['Code'])) == 9 else 0, axis=1)
            
            display_df = pd.DataFrame({
                'Code': report['Code'], 'Account Name': report['Account Name'],
                'Beg Dr': report['Beg Dr Display'], 'Beg Cr': report['Beg Cr Display'],
                'Move Dr': report['Move_Dr'], 'Move Cr': report['Move_Cr'],
                'Total Dr': report['Total_Dr'], 'Total Cr': report['Total_Cr'],
                'Final Dr': report['Final_Dr'], 'Final Cr': report['Final_Cr']
            })
            st.dataframe(display_df.sort_values('Code'), use_container_width=True)

        with t2:
            st.subheader("General Journal Log")
            st.dataframe(st.session_state.df_entries, use_container_width=True)

    except Exception as e:
        st.error(f"Error Detail: {e}")